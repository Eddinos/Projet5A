angular.module('mediaService', []).service('media', mediaFnc);

mediaFnc.$inject=['$http','$q'];

function mediaFnc($http, $q) 
{
	var fncContainer={
		addContent:addContent, saveContent:saveContent
	};

	var contentToSend = {
		"companyName": "",
		"contents": []
	}

	var contentData = {
		"type": "",
		"name": "",
		"code": ""
	}


	function addContent(file, companyName){
		console.log(file);


		var reader = new FileReader();
		reader.onload = function(event) {
			var data = event.target.result;

			console.log(data);

			contentToSend.companyName = companyName;
			var newData = {
				"type": file.type.split('/')[0],
				"code": data, 
				"name": file.name
			};
			contentToSend.contents.push(newData);
			console.log(contentToSend);
		};
		reader.readAsDataURL(file);
		
	}

	function saveContent()
	{
		var deferred = $q.defer();
		$http.post('#', contentToSend)
			.success(function(data, status, headers, config)
			{
				deferred.resolve("Contents successfully added to your list");
			})
			.
			error(function(data, status, headers, config)
			{
				deferred.reject("Addition of new content failed");
			});

		contentToSend.contents = [];
		return deferred.promise;
	}

	return fncContainer;

}