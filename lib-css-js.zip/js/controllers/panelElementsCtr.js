angular.module('App').controller('panelElementsCtrl',panelElementsCtrFnt);

panelElementsCtrFnt.$inject=['$scope','$log', '$window', '$http', '$q'];



function panelElementsCtrFnt($scope, $log, $window, $http, $q)
{
	$scope.elementMap = [];

	this.pelements = ["ok", "ko"];

	$scope.addElement = function(element){
		$scope.elementMap.push(element);
		console.log($scope.elementMap);
		console.log(pelements);
	};
}